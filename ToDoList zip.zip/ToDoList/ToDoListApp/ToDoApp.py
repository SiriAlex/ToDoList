import datetime
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox

class ToDoList:
    def __init__(self):
        self.tasks = {}  # Stores task info with task ID as key
        self.current_task_id = 0
        self.load_tasks()

    def add_task(self, description, due_date):
        self.current_task_id += 1
        task_info = {
            "id": self.current_task_id,
            "description": description,
            "due_date": due_date,
            
            "creation_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "completed": False
        }
        self.tasks[self.current_task_id] = task_info
        self.save_tasks()
        return f"Task '{description}' added successfully with ID {self.current_task_id}."

    def edit_task(self, task_id, new_description=None, new_due_date=None):
        if task_id in self.tasks:
            if new_description:
                self.tasks[task_id]['description'] = new_description
            if new_due_date:
                self.tasks[task_id]['due_date'] = new_due_date
            self.save_tasks()
            return f"Task ID {task_id} updated successfully."
        else:
            return "Task ID not found."

    def mark_task_completed(self, task_id):
        if task_id in self.tasks:
            self.tasks[task_id]['completed'] = True
            self.save_tasks()
            return f"Task ID {task_id} marked as completed."
        else:
            return "Task ID not found."

    def delete_task(self, task_id):
        if task_id in self.tasks:
            del self.tasks[task_id]
            self.save_tasks()
            return f"Task ID {task_id} deleted successfully."
        else:
            return "Task ID not found."

    def view_tasks(self):
        for task_id, task_info in self.tasks.items():
            status = "Completed" if task_info['completed'] else "Pending"
            print(f"ID: {task_id}, Description: {task_info['description']}, Due Date: {task_info['due_date']}, Status: {status}, Creation Date: {task_info['creation_date']}")

    def save_tasks(self):
        with open("tasks.json", "w") as file:
            json.dump(self.tasks, file, indent=4)

    def load_tasks(self):
        if os.path.exists("tasks.json"):
            with open("tasks.json", "r") as file:
                self.tasks = json.load(file)
                self.current_task_id = max(self.tasks.keys(), default=0)

class ToDoApp:
    def __init__(self, root):
        self.todolist = ToDoList()
        self.root = root
        self.root.title("To-Do List Application")
        self.setup_ui()

    def setup_ui(self):
        self.style = ttk.Style()
        self.style.theme_use("clam")

        self.task_frame = ttk.Frame(self.root, padding="10")
        self.task_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.task_listbox = tk.Listbox(self.task_frame, width=50, height=10)
        self.task_listbox.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        self.scrollbar = ttk.Scrollbar(self.task_frame, orient=tk.VERTICAL, command=self.task_listbox.yview)
        self.scrollbar.grid(row=0, column=1, sticky=(tk.N, tk.S))
        
        self.task_listbox.config(yscrollcommand=self.scrollbar.set)
        
        self.entry_frame = ttk.Frame(self.root, padding="10")
        self.entry_frame.grid(row=1, column=0, sticky=(tk.W, tk.E))

        self.task_entry = ttk.Entry(self.entry_frame, width=30)
        self.task_entry.grid(row=0, column=0, padx=5)
        
        self.due_date_entry = ttk.Entry(self.entry_frame, width=20)
        self.due_date_entry.grid(row=0, column=1, padx=5)
        self.due_date_entry.insert(0, "YYYY-MM-DD")

        self.add_button = ttk.Button(self.entry_frame, text="Add Task", command=self.add_task)
        self.add_button.grid(row=0, column=2, padx=5)

        self.complete_button = ttk.Button(self.entry_frame, text="Complete Task", command=self.complete_task)
        self.complete_button.grid(row=0, column=3, padx=5)

        self.delete_button = ttk.Button(self.entry_frame, text="Delete Task", command=self.delete_task)
        self.delete_button.grid(row=0, column=4, padx=5)

        self.load_tasks_to_listbox()

    def add_task(self):
        description = self.task_entry.get()
        due_date = self.due_date_entry.get()
        if description and due_date:
            message = self.todolist.add_task(description, due_date)
            messagebox.showinfo("Info", message)
            self.load_tasks_to_listbox()
            self.task_entry.delete(0, tk.END)
            self.due_date_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Warning", "Please enter a task description and due date.")

    def complete_task(self):
        try:
            selected_task = self.task_listbox.get(self.task_listbox.curselection())
            task_id = int(selected_task.split(",")[0].split()[1])  # Extract ID from string
            message = self.todolist.mark_task_completed(task_id)
            messagebox.showinfo("Info", message)
            self.load_tasks_to_listbox()
        except:
            messagebox.showwarning("Warning", "Please select a task to mark as complete.")

    def delete_task(self):
        try:
            selected_task = self.task_listbox.get(self.task_listbox.curselection())
            task_id = int(selected_task.split(",")[0].split()[1])  # Extract ID from string
            message = self.todolist.delete_task(task_id)
            messagebox.showinfo("Info", message)
            self.load_tasks_to_listbox()
        except:
            messagebox.showwarning("Warning", "Please select a task to delete.")

    def load_tasks_to_listbox(self):
        self.task_listbox.delete(0, tk.END)
        for task_id, task_info in self.todolist.tasks.items():
            status = "Completed" if task_info['completed'] else "Pending"
            self.task_listbox.insert(tk.END, f"ID: {task_id}, {task_info['description']} (Due: {task_info['due_date']}) - {status}")

if __name__ == "__main__":
    root = tk.Tk()
    app = ToDoApp(root)
    root.mainloop()
