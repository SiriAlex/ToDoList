# todo_list.py
import datetime
import json
import os

class ToDoList:
    def __init__(self):
        self.tasks = {}  # Stores task info with task ID as key
        self.current_task_id = 0
        self.load_tasks()

    def add_task(self, description, due_date):
        self.current_task_id += 1
        task_info = {
            "id": self.current_task_id,
            "description": description,
            "due_date": due_date,
            "creation_date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "completed": False
        }
        self.tasks[self.current_task_id] = task_info
        self.save_tasks()
        return f"Task '{description}' added successfully with ID {self.current_task_id}."

    def mark_task_completed(self, task_id):
        if task_id in self.tasks:
            self.tasks[task_id]['completed'] = True
            self.save_tasks()
            return f"Task ID {task_id} marked as completed."
        else:
            return "Task ID not found."

    def view_tasks(self):
        if not self.tasks:
            return "No tasks available."
        task_list = []
        for task_id, task_info in self.tasks.items():
            status = "Completed" if task_info['completed'] else "Pending"
            task_list.append(f"ID: {task_id}, Description: {task_info['description']}, Due Date: {task_info['due_date']}, Status: {status}, Creation Date: {task_info['creation_date']}")
        return "\n".join(task_list)

    def save_tasks(self):
        with open("tasks.json", "w") as file:
            json.dump(self.tasks, file, indent=4)

    def load_tasks(self):
        if os.path.exists("tasks.json"):
            with open("tasks.json", "r") as file:
                self.tasks = json.load(file)
                self.current_task_id = max(self.tasks.keys(), default=0)
